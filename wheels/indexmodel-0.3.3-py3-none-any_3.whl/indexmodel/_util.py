import faiss
import numpy as np
import pandas as pd

from typing import Union, Tuple
from pathlib import Path
from indexmodel import SSIndex
from io import BytesIO

INDEX_SAVE_NAME = "index.npy"
META_DATA_SAVE_NAME = "meta.parquet"


def save_index(index: SSIndex, path: Union[Path, str]) -> None:
    index_data = faiss.serialize_index(index.index)
    np.save(Path(path) / INDEX_SAVE_NAME, index_data)
    index.meta.to_parquet(Path(path) / META_DATA_SAVE_NAME)


def load_index(path: Union[Path, str], mapping: str) -> SSIndex:
    index = faiss.deserialize_index(np.load(Path(path) / INDEX_SAVE_NAME))
    meta = pd.read_parquet(Path(path) / META_DATA_SAVE_NAME)
    return SSIndex(index, meta, mapping)


def load_index_from_buffer(index: BytesIO, meta: BytesIO, mapping: str) -> SSIndex:
    _meta = pd.read_parquet(meta)
    _index = faiss.deserialize_index(np.load(index,  allow_pickle=True))
    return SSIndex(_index, _meta, mapping)


def index_to_byte_buffer(index: SSIndex) -> Tuple[BytesIO, BytesIO]:
    index_buffer, meta_buffer = BytesIO(), BytesIO()
    index_data = faiss.serialize_index(index.index)
    np.save(index_buffer, index_data, allow_pickle=True)
    index.meta.to_parquet(meta_buffer)
    return index_buffer, meta_buffer
