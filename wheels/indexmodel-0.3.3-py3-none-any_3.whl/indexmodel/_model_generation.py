import numpy as np
import numpy.typing as npt
import pandas as pd
from typing import List
from faiss import IndexFlatL2
from typing import Any


class SSIndex:
    def __init__(self, index: IndexFlatL2, meta_data: pd.DataFrame, 
                 mapping: Any) :
        if index.ntotal != len(meta_data):
            raise Exception("index and meta_data do not have the same length...")
        if mapping not in meta_data.columns:
            raise KeyError(f"mapping '{mapping}' not in meta_data columns...")
        self._mapping = mapping
        self.index = index
        self.meta = meta_data
        self._update_label()
        
    def search(self, x, k):
        dis, pos = self.index.search(x, k=k)
        return self._map(dis, pos)

    def add(self, embeddings: npt.NDArray[np.float32], meta_data: pd.DataFrame) -> int:
        if len(embeddings) != len(meta_data):
            raise Exception("embeddings and meta_data do not have the same length...")
        # add new embeddings to index
        self.index.add(embeddings)
        # append meta data
        self.meta = pd.concat([self.meta, meta_data]).reset_index(drop=True)
        self._update_label()
        return len(embeddings)

    def remove(self, pos:List[int]) -> int:
        _index = self.index
        n_removed = _index.remove_ids(np.array(pos))
        new_meta = self.meta.drop(pos).reset_index(drop=True)

        if (len(self.meta) - len(new_meta)) == n_removed:
            self.index = _index
            self.meta = new_meta
            self._update_label()
            return n_removed
        else:
            raise Exception("Error: len of removed embeddings != of removed metadata")

    def get_positions(self, values:List, label:str) -> List:
        _pos = self.meta[self.meta[label].isin(values)].index
        return list(_pos)

    def set_mapping(self, mapping):
        self._mapping = mapping
        self._update_label()

    def _map(self, distenses, position):
        mapped_data = []
        for dis, items in zip(distenses, position):
            mapped_data.append(
                [(self._label[item], d) for d, item in zip(dis, items)])
        return mapped_data

    def _update_label(self):
        self._label = self.meta[self._mapping].to_numpy()

    # give you the meta data for all items in one label group... 
    def get_label_groupe(self, label: Any) -> pd.DataFrame:
        df = self.meta
        return df[df[self._mapping] == label]
    